<!-- filepath: /c:/Users/User/OneDrive/Desktop/XAMPP/htdocs/WINTER ARC/testies.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winter Arc Gym - Testimonials</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="logo">
            <video class="logo-video" autoplay muted loop playsinline>
                <source src="WINTER ARC GYM.mp4" type="video/mp4">
            </video>
            <h1>WINTER ARC <span class="highlight">GYM</span></h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="membership.html">Membership</a></li>
                <li class="dropdown">
                    <a href="#about" class="dropbtn">About</a>
                    <div class="dropdown-content">
                        <a href="gallery.html">Gallery</a>
                        <a href="motivations.html">Motivation</a>
                        <a href="testies.php">Testimonial</a>
                    </div>
                </li>
                <li><a href="supplement.html">Supplements</a></li>
            </ul>
        </nav>
    </header>

    <!-- Testimonial Section -->
    <main>
        <section class="testimonials">
            <h2>TESTIMONIALS</h2>
            <div class="testimonial-container">
                <?php
                // Database connection details
                $servername = "localhost";
                $username = "root";
                $password = ""; // Default password for XAMPP is empty
                $dbname = "winter_arc_gym";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch reviews from the database
                $sql = "SELECT name, review, rating, submitted_at FROM reviews ORDER BY submitted_at DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<div class='testimonial'>";
                        echo "<h3>" . htmlspecialchars($row['name']) . "</h3>";
                        echo "<p>" . htmlspecialchars($row['review']) . "</p>";
                        echo "<div class='stars'>" . str_repeat("★", $row['rating']) . "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No reviews yet. Be the first to leave one!</p>";
                }

                $conn->close();
                ?>
            </div>
        </section>

        <!-- Add Review Section -->
        <section class="add-review">
            <h2>Leave a Review</h2>
            <form action="submit_review.php" method="POST">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="review">Your Review:</label>
                <textarea id="review" name="review" required></textarea>

                <label for="rating">Rating (1-5):</label>
                <select id="rating" name="rating" required>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>

                <button type="submit">Submit Review</button>
            </form>
        </section>
    </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2024 Winter Arc Gym. All Rights Reserved.</p>
    </footer>
</body>
</html>