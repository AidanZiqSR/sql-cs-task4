<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = ""; // Default password for XAMPP is empty
$dbname = "winter_arc_gym";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $review = htmlspecialchars($_POST['review']);
    $rating = intval($_POST['rating']);

    // Insert the review into the database
    $sql = "INSERT INTO reviews (name, review, rating) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $name, $review, $rating);

    if ($stmt->execute()) {
        // Redirect back to the testimonials page with a success message
        header("Location: testies.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    exit();
} else {
    // If the request method is not POST, redirect to testimonials page
    header("Location: testies.html");
    exit();
}
?>
