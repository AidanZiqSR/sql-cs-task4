// Hero Title and Subtitle Animation
gsap.to(".anim-title", { 
    duration: 1, 
    opacity: 1, 
    y: 0, 
    delay: 0.5, 
    ease: "power2.out" 
});

gsap.to(".anim-subtitle", { 
    duration: 1, 
    opacity: 1, 
    y: 0, 
    delay: 1, 
    ease: "power2.out" 
});

// Dropdown Bounce Effect
document.querySelector('.dropbtn').addEventListener('mouseover', () => {
    gsap.to(".dropbtn", {
        duration: 0.3,
        scale: 1.1,
        ease: "bounce.out",
    });
});

document.querySelector('.dropbtn').addEventListener('mouseout', () => {
    gsap.to(".dropbtn", {
        duration: 0.3,
        scale: 1,
        ease: "power2.out",
    });
});
